<?php

namespace App\Http\Controllers;

use App\Models\inventaris;
use Illuminate\Http\Request;

class InventarisController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public $inventaris;
    public function __construct()
    {
        $this->inventaris = new inventaris();
    }
    public function index()
    {
        $inventaris = inventaris::all();
        return view('inventaris.index', compact('inventaris'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('inventaris.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $rules = [
            'nama_barang' => 'required|min:3|max:200',
            'jenis_barang' => 'required|min:3|max:200',
            'kode_barang' => 'required|min:2|max:200',
            'deskripsi_barang' => 'required|min:3|',
        ];
        $message = [
            'required' => 'harus diisi',
            'min' => 'minimal 3 huruf',
            'max' => 'maximal 200 huruf'
        ];
        $request->validate($rules, $message);
        // nilai yang pertama itu dari db yang kedua itu nama form kita
        $this->inventaris->nama_barang = $request->nama_barang;
        $this->inventaris->jenis_barang = $request->jenis_barang;
        $this->inventaris->kode_barang = $request->kode_barang;
        $this->inventaris->deskripsi_barang = $request->deskripsi_barang;
        $this->inventaris->save();
        return redirect()->route('inventaris.index');
        // dd($request->all());
    }

    /**
     * Display the specified resource.
     */
    public function show(inventaris $inventaris)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $inventaris = inventaris::findOrFail($id);
        return view('inventaris.edit', compact('inventaris'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $updated = inventaris::findOrFail($id);
        $updated->nama_barang = $request->nama_barang;
        $updated->jenis_barang = $request->jenis_barang;
        $updated->kode_barang = $request->kode_barang;
        $updated->deskripsi_barang = $request->deskripsi_barang;
        // cek apakah ada atau tidak pakai isdirty()
        if ($updated->isDirty()) {

            // pesan
            $rules = [
                'nama_barang' => 'unique:inventaris,nama_barang',
                'jenis_barang' => 'unique:inventaris,jenis_barang',
                'kode_barang' => 'unique:inventaris,kode_barang',
                'deskripsi_barang' => 'unique:inventaris,deskripsi_barang',
            ];
            $message = [
                'required' => 'harus diisi',
                'unique' => 'Nama sudah ada silahkan ganti'
            ];
            $request->validate($rules, $message);
            $updated->nama_barang = $request->nama_barang;
            $updated->jenis_barang = $request->jenis_barang;
            $updated->kode_barang = $request->kode_barang;
            $updated->deskripsi_barang = $request->deskripsi_barang;
            $updated->save();
            return redirect()->route('inventaris.index');
        } else {
            return redirect()->route('inventaris.index');
            echo 'gagal updated';
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $delete = inventaris::findOrFail($id);
        // delete() = buat ngapus data
        $delete->delete();
        dd($delete);
        return redirect()->route('inventaris.index');
    }
}
