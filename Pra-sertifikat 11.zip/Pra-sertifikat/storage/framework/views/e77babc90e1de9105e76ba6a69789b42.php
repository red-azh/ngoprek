<?php $__env->startSection('konten'); ?>
<a href="<?php echo e(route('inventaris.create')); ?>">
    <button class="btn btn-success">Tambah</button>
</a>
<div class="table-responsive">
    <table class="table">
        <thead>

            <tr>
                <th>#</th>
                <th>Nama Barang</th>
                <th>Jenis barang</th>
                <th>Kode barang</th>
                <th>Deskripsi Barang</th>
                <th></th>
            </tr>
        </thead>
        <?php
        $no = 1;
        ?>
        <tbody>
            <?php $__currentLoopData = $inventaris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($item->nama_barang); ?></td>
                <td><?php echo e($item->jenis_barang); ?></td>
                <td><?php echo e($item->kode_barang); ?></td>
                <td><?php echo e($item->deskripsi_barang); ?></td>
                <td>
                    <a href="<?php echo e(route('inventaris.edit', $item->id)); ?>" class="btn btn-warning">Edit</a>
                    <a href="<?php echo e(route('inventaris.destroy', $item->id)); ?>" class="btn btn-primary"
                        onclick="return confirm('Yakin nih?')">Delete</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/petik/Documents/Pra-sertifikat/resources/views/inventaris/index.blade.php ENDPATH**/ ?>