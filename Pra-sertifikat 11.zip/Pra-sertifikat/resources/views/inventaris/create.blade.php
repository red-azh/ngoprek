@extends('master.app')
@section('konten')
<div class="col-sm-12 col-xl-6">
    <div class="bg-secondary rounded h-100 p-4">
        <h6 class="mb-4">Tambah Form</h6>
        <form action="{{route('inventaris.store')}}" method="post">
            @csrf
            <div class="mb-3">
                <label class="form-label">Nama Barang</label>
                <input type="text" class="form-control" name="nama_barang">
            </div>
            <div class="mb-3">
                <label class="form-label">Kode Barang</label>
                <input type="text" class="form-control" name="kode_barang">
            </div>
            <div class="mb-3">
                <label class="form-label">Jenis Barang</label>
                <input type="text" class="form-control" name="jenis_barang">
            </div>
            <div class="mb-3">
                <label class="form-label">Deskripsi Barang</label>
                <input type="text" class="form-control" name="deskripsi_barang">
            </div>
            <button type="submit" class="btn btn-primary">Tambah</button>
        </form>
    </div>
</div>
@endsection
