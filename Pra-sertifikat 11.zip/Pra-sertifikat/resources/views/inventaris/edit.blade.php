@extends('master.app')
@section('konten')
<div class="col-sm-12 col-xl-6">
    <div class="bg-secondary rounded h-100 p-4">
        <h6 class="mb-4">Edit Form</h6>
        <form action="{{route('inventaris.update', $inventaris->id)}}" method="post">
            @method('PUT')
            @csrf
            <div class="mb-3">
                <label class="form-label">Nama Barang</label>
                <input type="text" class="form-control" name="nama_barang" value="{{$inventaris->nama_barang}}">
            </div>
            @error('nama_barang')
            <p class="text-danger">{{$message}}</p>
            @enderror
            <div class="mb-3">
                <label class="form-label">Kode Barang</label>
                <input type="text" class="form-control" name="kode_barang" value="{{$inventaris->kode_barang}}">
            </div>
            @error('kode_barang')
            <p class="text-danger">{{$message}}</p>
            @enderror
            <div class="mb-3">
                <label class="form-label">Jenis Barang</label>
                <input type="text" class="form-control" name="jenis_barang" value="{{$inventaris->jenis_barang}}">
            </div>
            @error('jenis_barang')
            <p class="text-danger">{{$message}}</p>
            @enderror
            <div class="mb-3">
                <label class="form-label">Deskripsi Barang</label>
                <input type="text" class="form-control" name="deskripsi_barang"
                    value="{{$inventaris->deskripsi_barang}}">
            </div>
            @error('deskripsi_barang')
            <p class="text-danger">{{$message}}</p>
            @enderror
            <button type="submit" class="btn btn-primary">Updated</button>
        </form>
    </div>
</div>
@endsection
