@extends('master.app')
@section('konten')
<a href="{{route('inventaris.create')}}">
    <button class="btn btn-success">Tambah</button>
</a>
<div class="table-responsive">
    <table class="table">
        <thead>

            <tr>
                <th>#</th>
                <th>Nama Barang</th>
                <th>Jenis barang</th>
                <th>Kode barang</th>
                <th>Deskripsi Barang</th>
                <th></th>
            </tr>
        </thead>
        @php
        $no = 1;
        @endphp
        <tbody>
            @foreach($inventaris as $item)
            <tr>
                <td>{{$no++}}</td>
                <td>{{ $item->nama_barang }}</td>
                <td>{{ $item->jenis_barang }}</td>
                <td>{{ $item->kode_barang }}</td>
                <td>{{ $item->deskripsi_barang }}</td>
                <td>
                    <a href="{{ route('inventaris.edit', $item->id) }}" class="btn btn-warning">Edit</a>
                    <a href="{{ route('inventaris.destroy', $item->id) }}" class="btn btn-primary"
                        onclick="return confirm('Yakin nih?')">Delete</a>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection