<?php $__env->startSection('konten'); ?>
<a href="<?php echo e(route('kategori.create')); ?>" class="btn btn-success">tambah data</a>
<div class="table-responsive">
    <table class="table">
        <tr>
            <th>No</th>
            <th>Nama Kategori</th>
            <th></th>
        </tr>
        <?php
        $no = 1;
        ?>
        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($item->nama_kategori); ?></td>
            <td class="d-flex">
                <a href="<?php echo e(route('kategori.edit', $item->id)); ?>" class="btn btn-warning me-2">Edit</a>
                <form action="<?php echo e(route('kategori.destroy', $item->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-primary" onclick="return confirm('Yakin nih?')">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/petik/Documents/ngoprek/pra-ukom/resources/views/kategori/table.blade.php ENDPATH**/ ?>