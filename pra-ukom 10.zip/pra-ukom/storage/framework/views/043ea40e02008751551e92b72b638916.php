<?php $__env->startSection('konten'); ?>
<form action="<?php echo e(route('berita.index')); ?>" method="get">
    <div class="d-flex">
        <input type="text" class="form-control m-0" placeholder="Search" style="width: 200px">
        <button type="submit" name="search" class="btn btn-success">
            <i class="fa fa-search me-1"></i>Cari
        </button>
    </div>
</form>
<a href="<?php echo e(route('berita.create')); ?>" class="btn btn-success">tambah</a>
<div class="table-responsive">
    <table class="table">
        <tr>
            <th>No</th>
            <th>Judul Berita</th>
            <th>Deskripsi</th>
            <th>Kategori</th>
            <th></th>
        </tr>
        <?php
        $no = 1;
        ?>
        <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($item->judul); ?></td>
            <td><?php echo e(strlen($item->deskripsi) > 100 ? substr($item->deskripsi, 0, 100) . '...' : $item->deskripsi); ?></td>
            <td><?php echo e($item->kategori_id); ?></td>
            <td class="d-flex">
                <a href="<?php echo e(route('berita.edit', $item->id)); ?>" class="btn btn-warning me-2">Edit</a>
                <form action="<?php echo e(route('berita.destroy', $item->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-primary" onclick="return confirm('Yakin nih?')">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/petik/Documents/ngoprek/pra-ukom/resources/views/berita/table.blade.php ENDPATH**/ ?>