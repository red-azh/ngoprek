@extends('master.app')

@section('konten')
<a href="{{route('lembaga.create')}}" class="btn btn-success">tambah</a>
<div class="table-respponsive">
    <table class="table">
        <tr>
            <th>#</th>
            <th>Nama Lembaga</th>
            <th>Alamat Lembaga</th>
            <th></th>

        <tr>
            @php
            $no = 1;
            @endphp
            @foreach ($lembaga as $item)
        </tr>

        <td>{{$no++}}</td>
        <td>{{$item->nama_lembaga}}</td>
        <td>{{$item->alamat_lembaga}}</td>
        <td class="d-flex">
            <a href="{{route('lembaga.show', $item->id)}}" class="btn btn-info">show</a>
            <a href="{{route('lembaga.edit', $item->id)}}" class="btn btn-warning mx-2">Edit</a>
            <form action="{{ route('lembaga.destroy', $item->id) }}" method="POST">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-primary" onclick="return confirm('Yakin nih?')">Delete</button>
            </form>
        </td>
        </tr>
        @endforeach
    </table>
</div>
@endsection