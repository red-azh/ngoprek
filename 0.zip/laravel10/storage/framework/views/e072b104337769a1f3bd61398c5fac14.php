<?php $__env->startSection('konten'); ?>
<a href="<?php echo e(route('pengurus.create')); ?>" class="btn btn-success mb-3">tambah</a>
<div class="table-respponsive">
    <table class="table">
        <tr>
            <th>#</th>
            <th>Ketua</th>
            <th>Sekretaris</th>
            <th>Bendahara</th>
            <th></th>

        <tr>
            <?php
            $no = 1;
            ?>
            <?php $__currentLoopData = $pengurus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        </tr>

        <td><?php echo e($no++); ?></td>
        <td><?php echo e($item->ketua); ?></td>
        <td><?php echo e($item->sekretaris); ?></td>
        <td><?php echo e($item->bendahara); ?></td>
        <td class="d-flex">
            <a href="<?php echo e(route('pengurus.show', $item->id)); ?>" class="btn btn-info">show</a>
            <a href="<?php echo e(route('pengurus.edit', $item->id)); ?>" class="btn btn-warning mx-2">Edit</a>
            <form action="<?php echo e(route('pengurus.destroy', $item->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-primary" onclick="return confirm('Yakin nih?')">Delete</button>
            </form>
        </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/petik/Documents/ngoprek/laravel10/resources/views/pengurus/index.blade.php ENDPATH**/ ?>