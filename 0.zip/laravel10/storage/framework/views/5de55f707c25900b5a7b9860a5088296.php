<?php $__env->startSection('konten'); ?>
<a href="<?php echo e(route('lembaga.index')); ?>" class=" btn btn-warning mb-4 ms-2">Kembali</a>
<div class="container">
    <div class="row">
        <div class="col-md-3">
            <h3>Detail Lembaga</h3>
        </div>
        <div class="col-md-9">
            <table class="table">

                <tr>
                    <th>Nama Lembaga :</th>
                    <td><?php echo e($lembaga->nama_lembaga); ?></td>
                </tr>

                <tr>
                    <th>Alamat Lembaga : </th>
                    <td><?php echo e($lembaga->alamat_lembaga); ?></td>
                </tr>
                <tr>
                    <th>Terakhir Dibuat :</th>
                    <td><?php echo e($lembaga->created_at); ?></td>
                </tr>
                <tr>
                    <th>Terakhir Diperbarui :</th>
                    <td><?php echo e($lembaga->updated_at); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/petik/Documents/ngoprek/laravel10/resources/views/lembaga/show.blade.php ENDPATH**/ ?>