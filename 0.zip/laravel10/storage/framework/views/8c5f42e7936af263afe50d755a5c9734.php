<?php $__env->startSection('konten'); ?>
<a href="<?php echo e(route('pengurus.index')); ?>" class=" btn btn-warning mb-4 ms-2">Kembali</a>
<div class="container">
    <div class="row">
        <div class="col-md-3">
            <h3>Detail Pengurus</h3>
        </div>
        <div class="col-md-9">
            <table class="table">

                <tr>
                    <th>Nama Ketua :</th>
                    <td><?php echo e($pengurus->ketua); ?></td>
                </tr>

                <tr>
                    <th>Nama Bendahara : </th>
                    <td><?php echo e($pengurus->sekretaris); ?></td>
                </tr>
                <tr>
                    <th>Nama Bendahara : </th>
                    <td><?php echo e($pengurus->bendahara); ?></td>
                </tr>
                <tr>
                    <th>Terakhir Dibuat :</th>
                    <td><?php echo e($pengurus->created_at); ?></td>
                </tr>
                <tr>
                    <th>Terakhir Diperbarui :</th>
                    <td><?php echo e($pengurus->updated_at); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/petik/Documents/ngoprek/laravel10/resources/views/pengurus/show.blade.php ENDPATH**/ ?>